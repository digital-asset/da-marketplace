from .exchange_bot import main

main()
