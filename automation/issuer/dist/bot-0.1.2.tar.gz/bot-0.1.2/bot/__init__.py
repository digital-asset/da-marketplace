from .issuer_bot import main

main()
