from .operator_bot import main

main()
