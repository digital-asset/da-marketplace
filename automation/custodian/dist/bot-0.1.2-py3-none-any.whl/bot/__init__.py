from .custodian_bot import main

main()
