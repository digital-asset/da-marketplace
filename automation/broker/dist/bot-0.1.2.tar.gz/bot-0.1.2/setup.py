# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bot']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.6.2,<4.0.0', 'dazl>=6.7.4,<7.0.0']

setup_kwargs = {
    'name': 'bot',
    'version': '0.1.2',
    'description': 'The DA Marketplace Broker Bot',
    'long_description': None,
    'author': 'Digital Asset',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.9',
}


setup(**setup_kwargs)
