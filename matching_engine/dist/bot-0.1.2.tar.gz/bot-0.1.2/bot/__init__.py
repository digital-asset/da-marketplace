from .matching_engine_bot import main

main()
