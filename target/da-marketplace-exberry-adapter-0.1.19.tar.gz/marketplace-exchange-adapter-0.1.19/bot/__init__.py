from .exberry_adapter_bot import main

main()
